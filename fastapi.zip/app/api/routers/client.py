from fastapi import APIRouter, Request
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles

router = APIRouter(
    prefix="/client",
    tags=["client"],
    responses={404:{"description" : "Not Found"}}
)

# Serve static files
router.mount("/static", StaticFiles(directory="app/static"), name="static")

# Create a Jinja2Templates instance
templates = Jinja2Templates(directory="app/templates")

# Example data
data = [
    {"id": 1, "name": "John", "age": 30},
    {"id": 2, "name": "Alice", "age": 25},
    {"id": 3, "name": "Bob", "age": 35}
]

@router.get("/")
def client(request:Request):
    return templates.TemplateResponse("client.html", {"request":request})


@router.get("/data")
async def get_data():
    return {"data": data}
    
@router.post("/data")
def add_data():
    new_data = {}
    new_data["id"] = len(data) + 1
    new_data["name"] = "TestData"+ str(new_data["id"])
    new_data["age"] = "TestData"+ str(new_data["id"])
    data.append(new_data)
    return {'data':data}
