from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db.database import db
from app.db.models.user import User as UserModel
from app.db.schema.user import UserCreate
from app.db.schema.user import User as UserSchema

# from app.main import dataBase  # Import the existing dataBase instance from main.py

router = APIRouter(
    prefix="/user",
    tags=["user"],
    responses={404:{"description" : "Not Found"}}
)

@router.post("/", response_model=UserSchema)
def create_user(user: UserCreate, db: Session = Depends(db.get_db)):
    db_user = UserSchema(**user.dict())
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user

@router.get("/{user_id}", response_model=UserSchema)
def read_item(user_id: int, db: Session = Depends(db.get_db)):
    db_user = db.query(UserModel).filter(UserModel.id == user_id).first()
    if db_user is None:
        raise HTTPException(status_code=404, detail="Item not found")
    return db_user