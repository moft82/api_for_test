from fastapi import APIRouter, WebSocket

router = APIRouter(
    prefix="/ws",
    tags=["websocket"],
)
connections : list[WebSocket] = []

@router.websocket("/websocket")
async def websocket_endpoint(websocket: WebSocket):
    # Accept the WebSocket connection
    await websocket.accept()
    
    print(f"client connected : {websocket.client}")
    connections.append(websocket)

    try:
        # Continuously listen for messages
        while True:
            # Receive message from the client
            message = await websocket.receive_text()
            # Handle the message (optional)
            print(f"Received message from client: {message} from :{websocket.client}")
            for sockets in connections:
                await sockets.send_text("update")
    except Exception as e:
        print(f"WebSocket connection closed with error: {e}")
    finally:
        # Remove the connection from the list when the connection is closed
        connections.remove(websocket)