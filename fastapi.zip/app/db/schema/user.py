from pydantic import BaseModel
from app.db.schema.item import Item

class UserBase(BaseModel):
    name: str
    description: str

class UserCreate(UserBase):
    pass

class User(UserBase):
    id: int
    items: list[Item] = []

    class Config:
        from_attributes = True