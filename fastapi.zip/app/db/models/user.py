from sqlalchemy import Column, String, Integer
from sqlalchemy.orm import relationship
from app.db.database import Base

class User(Base):
    __tablename__ = "user"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(20))
    email = Column(String(40), index=True)
    full_name = Column(String(40))
    items = relationship("Item", back_populates="user")
    