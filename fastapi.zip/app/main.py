from fastapi import FastAPI
from app.core.config import Config
from app.api.routers import item, real_time, user, websocket, client, manage
from app.db.database import Base, db
import uvicorn

def create_app() -> FastAPI:
    config = Config()  
    app = FastAPI(debug=config.DEBUG)
    app.include_router(user.router)
    app.include_router(item.router)
    app.include_router(websocket.router)
    app.include_router(client.router)
    app.include_router(real_time.router)
    app.include_router(manage.router)

    return app

app = create_app()

# Create tables
Base.metadata.create_all(bind=db.engine)

@app.get("/")
async def root():
    return {"message": "Hello World"}


if __name__ == "__main__":
    # uvicorn.run("app.main:app", host="127.0.0.1", port=8000)
    uvicorn.run("app", host="127.0.0.1", port=8000)

# uvicorn app.main:app --reload